class PreSet extends Article {
  // contains the number needed to generate true/false articles
  public fake: number;

  //Contains every pregenerated article from allFakeGens and allTrueGens
  private preGens: any[];

  constructor() {
    super();
    //randomly calculates if the article is true (0) or false (1)
    this.fake = Math.round(Math.random());
    //either fills the pregen array with fake news or true news
    console.log(this.fake);
    if (this.fake == 1) {
      this.allFakeGens();
    } else {
      this.allTrueGens();
    }
    this.textGen(this.fake);
  }

  private textGen(fake: number) {
    //for when we have an error it makes it clear wether or not it was successful
    super._header = "Header not found";
    super._author = "Author not found";
    super._text = "Text not found";
    super._source = "Source not found";
    super.bobux	= 0;
    super.credability = 0;
    //choose which article you should get
    let index = Math.floor(Math.random() * this.preGens.length / 6) * 6;

    //sends the right pregereated text into the super class defined protected strings
    super._header = this.preGens[index];
    super._author = this.preGens[index + 1];
    super._text = this.preGens[index + 2];
    super._source = this.preGens[index + 3];
    super.bobux = this.preGens[index + 4];
    super.credability = this.preGens[index + 5];
  }

  private allFakeGens() {
    //database of fake articles, every 4 lines of array = 1 Article
    // 1. Header
    // 2. Author
    // 3. Text
    // 4. Source
    // 5. Amount of Bobux
    // 6. Credability (0 = credible, 1 = not credible, etc.)
    this.preGens = [
      "Scientists Discover Super Rare Alien Planet",
      "Author: Mc-Fergunson, Earl of Scotland",
      "It was discovered yesterday that on the moon, there was a device communicating with an unknown planet. After research, weve discovered that this race of aliens is called Yakanbur. I hope it doesn't come back to bite us. Literally.",
      "Source: Huffington Post",
      250,
      1,
      

      "Big foot is back, But scottisch",
      "Author: Mc-Fergunson, Lord of Little Brechin",
      "Big foot has been spotted in Scotland, this is a first officials say. ",
      "Source: Reddit",
      100,
      1,

      "Slime(tm) is the best",
      "Author:the slime team",
      "All you have to do is join our pyramid scheme and the Slime will make your skin crystal clear",
      "Source:Article(1356 AD.)",
      200,
      1,

      "Free Bobux, just do these simple steps",
      "Author: Bob Buxer",
      "step one: give me your credit card information, step 2 fill in your log in data here, step 3:?, step 4: Profit!",
      "Source: Your mom",
      403,
      1,

      "Meteor to destroy earth in 1 month",
      "Author: Lemony Demard",
      "I think it's time for you to know the awful truth, I've been working on a unified theory, I'm an expert in my field, UFOlogy, yes, it's all real, Ancient aliens, it's all true",
      "Source: Home-made Research",
      350,
      1,
    

      "Red is sus",
      "Author: White impostor",
      "i donno man, he's just been standing there doing nothing",
      "Source: me",
      10304,
      1,

      "Being Stuck In Infinite Time Loop is the Issue",
      "Author: Anonymous",
      "Revealing a persistent concern within the pivotal voting bloc, a new poll from the Pew Research Center found Tuesday that being stuck in an infinite time loop was the biggest issue",
      "Source: the garlic",
      60,
      1,

      "These are the most expensive dogs. Period.",
      "Author: Fakian Namian",
      "they are originally from mars, and they've been blessed by Baba Yaga, which causes them to eat anything they can get their tentacles on",
      "Source: DogEmpire",
      230,
      1,

      "Old man Fuming Over Bad Boy.",
      "Author: Anonymous",
      "Lame person is not cool enough to realise the bad boy is right.",
      "Source: the garlic",
      430,
      1,

      "The big hairy Bigfoot in a café!",
      "Author: Anna Rose",
      "some say it's just a hairy man, but we don't think so.",
      "Source : gossip monster",
      210,
      1,

      "Copy Pasted article",
      "VEry cool author",
      "Balh blah blah",
      "Nice",
      0,
      1,
    ];
  }

  private allTrueGens() {
    //database of true articles,  every 4 lines of array = 1 Article
    // 1. Header
    // 2. Author
    // 3. Text
    // 4. Source
    // 5. Amount of Bobux
    // 6. Credability (0 = credible, 1 = not credible, etc.)
    this.preGens = [
      "New Covid rules have been made",
      "Author: Mei Miller",
      "only 2 people may be together in public, a 100 Bobux fine is given on violation",
      "Source: Official statement",
      50,
      0,

      "New Machine learning program animates!",
      "Author: two minute papers",
      "using a large pool of data, this program can simulate some very difficult problems",
      "https://matthias-research.github.io",
      40,
      0,


      "How sleep affects your emotions.. zzz",
      "Author: Bob Buxer",
      "So exactly, how does a lack of sleep impact our emotional brain? Why does that lack of sleep make us so emotionally irrational and hyperreactive? ",
      "Source: TED",
      50,
      0,


      "The difference between flows: Not a musical.",
      "Author: Veritasium",
      "Laminar flow is easier to understand since it gives a constant output, while Turbular flow is chaotic and requires more variables to be understood",
      "Source: Prof. Beverley McKeon",
      50,
      0,


      "Why Do We Play Games?",
      "Author: Michael",
      "It's a primal desire to feel like you acomplish something, and playing games can be a shortcut to get those feelings, in short because it's fun continue reading to learn why.",
      "Source: Vsauce",
      50,
      0,


      "How we could make carbon-negative concrete?",
      "Author: Matt Walker",
      "Tom Schuler previews an innovative way to create concrete, potentially turning it into a carbon sink that traps CO2 from the atmosphere -- while producing a viable building material.",
      "Source: TED",
      50,
      0,


      "How do Chameleon Tongues work?",
      "Author: Destin(Smarter every day)",
      "Their tongue and mouth have a bunch of muscles with a sircular form which squeeze the tongue out of their mouth, their bones also play a huge role causing a 2-bar Mechanical linkage",
      "Source: Emily Graslie",
      50,
      0,


      "No tourists, and yet the beach is full of plastic",
      "Author: Marge Simpson",
      "About 30,000 to 60,000 kilos of plastic wash up on the beaches every day. That happens every year during this period, but this time it is worse than usual, this is weird because there are hardly any tourists.",
      "Source : NOS",
      50,
      0,
    ];
  }
}
