class Player {
    constructor() {
        
    }
}