class PreSet extends Article {
    // contains the number needed to generate true/false articles
    public fake: number;
    // contains every pregenerated article
    private preGens: string[];
    

    constructor() {
        super();
        //randomly calculates if the article is true (0) or false (1)
        this.fake = Math.round(Math.random());
        //either fills the pregen array with fake news or true news
        console.log(this.fake);
        if (this.fake == 1){
            this.allfakeGens();
        } else {
            this.alltrueGens();
        }
        this.textGen(this.fake);
    }

    private textGen(fake:number){
        // for when we have an error it makes it clear wether or not it was successful
        super._header = "Header not found";
        super._author = "Author not found";
        super._text	 = "Text not found";
        super._source = "Source not found";

        // choose which article you should get
        let index = Math.floor(Math.random()*this.preGens.length * 0.25) * 4;

        // sends the right pregereated text into the super class defined protected strings
        super._header = this.preGens[index];
        super._author = this.preGens[index+1];
        super._text = this.preGens[index+2];
        super._source = this.preGens[index+3];

        // placeholder for credebility generation and bobux generation
        super.bobux = Math.random() * 100;
        super.credability = Math.random()* 100 * this.fake;
    }

    private allfakeGens(){
        
        //database of fake articles, every 4 lines of array = 1 Article
        this.preGens = [
        "example fake header 1",
        "example fake author 1",
        "example fake text 1",
        "example fake source 1",
        

        "example fake header 2",
        "example fake author 2",
        "example fake text 2",
        "example fake source 2",
        

        "example fake header 3",
        "example fake author 3",
        "example fake text 3",
        "example fake source 3"];
        
    }

    private alltrueGens(){
        //database of true articles,  every 4 lines of array = 1 Article
        this.preGens = [
            "example true header 1",
            "example true author 1",
            "example true text 1",
            "example true source 1",
            
    
            "example true header 2",
            "example true author 2",
            "example true text 2",
            "example true source 2",
            
    
            "example true header 3",
            "example true author 3",
            "example true text 3",
            "example true source 3"];
    }
}