class Level {
    // Canvas
    private readonly canvas: HTMLCanvasElement;
    private readonly ctx: CanvasRenderingContext2D;
    // Needed values in order to end the game.
    protected difficulty: number;
    protected articles: number;
    protected time: number;
    private timeToProgress: number;
    
    constructor(difficulty: number, articles: number, time: number) {
        this.difficulty;
        this.articles;
        this.time;
    }

    
    //Checks if a level is completed: true/false
    public isCompleted = (): boolean => {
        return this.time >= this.timeToProgress
    }
    //function to update the frameindex to proceed to the next level
    public update = (frameIndex:number): void => {
    }
}