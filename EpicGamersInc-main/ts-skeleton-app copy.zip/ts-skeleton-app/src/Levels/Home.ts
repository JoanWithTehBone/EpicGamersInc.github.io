class Home {
    
    constructor() {
       
    }

    

}