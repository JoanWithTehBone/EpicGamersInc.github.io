class GameOver {
    constructor() {
    }
}