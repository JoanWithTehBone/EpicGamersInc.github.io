class TestImage {
    //All the properties needed to align the image on the screen
    private image: HTMLImageElement;
    private xPosition: number;
    private yPosition: number;

    constructor (item: string, xPos: number, yPos: number,) {
        this.image = this.loadNewImage(`assets/main-screen/${item}.png`)
        this.xPosition = xPos;
        this.yPosition = yPos;
    }

    /**
    * Draw all the necessary items to the screen
    */
    public draw(ctx:CanvasRenderingContext2D) {
        //Drawing Items to the screen
        console.log(ctx);
        ctx.drawImage(this.image, this.xPosition, this.yPosition);
}

    //Loading images on the screen each frame
    private loadNewImage(source: string): HTMLImageElement {
        const img = new Image();
        img.src = source;
        return img;
}
}