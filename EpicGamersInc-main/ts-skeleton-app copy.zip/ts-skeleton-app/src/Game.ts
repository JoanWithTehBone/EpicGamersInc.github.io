class Game {
    // The canvas
    private readonly canvas: HTMLCanvasElement;
    private readonly ctx: CanvasRenderingContext2D;
    //Different Callbacks to Images
    private levels: Level[]
    private currentLevel: number; 
    private testImage: TestImage;
    private testArticle: Article;
    // Current frame number
    private frameIndex: number;

    public constructor(canvas: HTMLElement) {
        this.canvas = <HTMLCanvasElement>canvas;
        this.ctx = this.canvas.getContext("2d");
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;

        

        this.levels = [];
        //Testing if getting a new article would log
        this.testArticle = new PreSet();
        console.log(this.testArticle.getArticle());
        //Testing if Images would display on the screen
        this.testImage = new TestImage ('Settings-Button', 0, 0)
        console.log(this.testImage);

        this.currentLevel = 0;
        this.frameIndex = 0;
        requestAnimationFrame(this.step);
    }

    /**
     * This MUST be an arrow method in order to keep the this constiable
     * working correctly. It will be overwritten by another object otherwise
     * caused by javascript scoping behaviour.
     */
    step = () => {
        this.frameIndex++;
        //const level = this.levels[this.currentLevel];
        //level.update(this.frameIndex);
        
        //if (level.isCompleted()) {
        //    this.currentLevel++
        //}
        this.draw();
        requestAnimationFrame(this.step);
    }

    private draw() {
        // Get the canvas rendering context
        const ctx = this.canvas.getContext('2d');
        
        // Clear the entire canvas
        ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        
        //Calling the fucntion to write all different text sources to the array
        // 1. Header
        // 2. Author
        // 3. Text
        // 4. Source
        this.writeTextToCanvas(ctx, this.testArticle.head, this.canvas.width * 0.75 , this.canvas.height * 0.75, 24);
        this.writeTextToCanvas(ctx, this.testArticle.auth, this.canvas.width * 0.75 , this.canvas.height * 0.75 + 20, 11);
        this.writeMultiLineToCanvas(ctx, this.testArticle.tex, this.canvas.width, this.canvas.height * 0.75, this.canvas.width * 0.75 + 38);
        this.writeTextToCanvas(ctx, this.testArticle.sour, this.canvas.width * 0.75 , this.canvas.height * 0.98, 11);


        
        //Test to display images
        this.testImage.draw(ctx);
    }

    /**
    * Writes text to the canvas
    * @param {string} text - Text to write
    * @param {number} fontSize - Font size in pixels
    * @param {number} xCoordinate - Horizontal coordinate in pixels
    * @param {number} yCoordinate - Vertical coordinate in pixels
    * @param {string} alignment - Where to align the text
    * @param {string} color - The color of the text
    */
    public writeTextToCanvas(
        ctx: CanvasRenderingContext2D,
        text: string,
        xCoordinate: number,
        yCoordinate: number,
        fontSize: number = 20,
        color: string = "green",
        alignment: CanvasTextAlign = "start"
    ) {
        ctx.font = `${fontSize}px sans-serif`;
        ctx.fillStyle = color;
        ctx.textAlign = alignment;
        ctx.fillText(text, xCoordinate, yCoordinate);
    }

    private writeMultiLineToCanvas(
        ctx: CanvasRenderingContext2D, 
        text: string, 
        maxWidth: number, 
        x: number, 
        y: number) {

        const words = text.split(" ");
        const lines = [];
        let currentLine = words[0];
        
        for (let i = 1; i < words.length; i++) {
            const word = words[i];
            const width = ctx.measureText(currentLine + " " + word).width;
            if (width < maxWidth) {
                currentLine += " " + word;
            } else {
                lines.push(currentLine);
                currentLine = word;
            }
        }
        lines.push(currentLine);
        const lineHeight = ctx.measureText("M").width * 1.2;
        for (let i = 0; i < lines.length; ++i) {
            ctx.fillText(lines[i], x, y);
            y += lineHeight;
        }
        console.log(lines);
    }

    
}